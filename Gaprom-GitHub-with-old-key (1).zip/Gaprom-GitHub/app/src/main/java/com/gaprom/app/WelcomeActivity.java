package com.gaprom.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;

public class WelcomeActivity extends AppCompatActivity {

private static final String[] TITLES = {  
    "به گپروم خوش آمدید", "بگو و بشنو!", "سرت گرم و دلت خوش!",  
    "نشود فاش کسی...", "این کرکره همیشه بالاست!"  
};  
private static final String[] SUBS = {  
    "کنار هم؛ بر خط ارتباط",  
    "تنوع، سرعت و کیفیت در برقراری ارتباط؛ از تماس صوتی تا تصویری",  
    "سرویس‌های محتوایی متنوع از ویدئو و پست‌چین تا پخش زنده",  
    "لایه‌های امنیتی در حریم خصوصی کاربر برای پیام‌رسانی امن و خیال راحت",  
    "میزبانی کسب‌وکارهای کوچک و بزرگ با امکانات مدیریت کانال و گروه"  
};  

private ViewPager2 pager;  
private LinearLayout dots;  
private DataStore store;  

@Override  
protected void onCreate(Bundle b) {  
    super.onCreate(b);  
    setContentView(R.layout.activity_welcome);  
    store = DataStore.get(this);  

    String theme = store.getTheme();  
    getDelegate().setLocalNightMode(  
            "light".equals(theme) ? androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO  
                    : androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES);  

    String phone = store.currentPhone();  
    if (phone != null && !phone.isEmpty() && store.isVerified(phone)) {  
        if (store.getProfile(phone) == null) startActivity(new Intent(this, ProfileActivity.class));  
        else startActivity(new Intent(this, MainActivity.class));  
        finish(); return;  
    }  

    pager = findViewById(R.id.pager);  
    dots = findViewById(R.id.dots);  
    ImageView themeBtn = findViewById(R.id.themeBtn);  
    Button cta = findViewById(R.id.cta);  

    pager.setAdapter(new Adapter());  
    buildDots(0);  
    pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {  
        @Override public void onPageSelected(int pos) { buildDots(pos); }  
    });  

    themeBtn.setOnClickListener(v -> {  
        boolean isDark = !"light".equals(store.getTheme());  
        store.setTheme(isDark ? "light" : "dark");  
        getDelegate().setLocalNightMode(isDark  
                ? androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO  
                : androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES);  
        recreate();  
    });  

    cta.setOnClickListener(v -> startActivity(new Intent(this, LoginActivity.class)));  
}  

private void buildDots(int active) {  
    dots.removeAllViews();  
    for (int i = 0; i < TITLES.length; i++) {  
        View v = new View(this);  
        int size = getResources().getDisplayMetrics().densityDpi / 160;  
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(  
                (i == active ? 18 : 6) * size, 6 * size);  
        lp.setMargins(3 * size, 0, 3 * size, 0);  
        v.setLayoutParams(lp);  
        v.setBackgroundResource(i == active ? R.drawable.dot_active : R.drawable.dot);  
        dots.addView(v);  
    }  
}  

private class Adapter extends RecyclerView.Adapter<Adapter.VH> {  
    @NonNull @Override  
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {  
        View v = LayoutInflater.from(parent.getContext())  
                .inflate(R.layout.item_slide, parent, false);  
        return new VH(v);  
    }  
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {  
        h.title.setText(TITLES[pos]);  
        h.sub.setText(SUBS[pos]);  
        h.icon.setImageResource(R.drawable.ic_gaprom);  
    }  
    @Override public int getItemCount() { return TITLES.length; }  
    class VH extends RecyclerView.ViewHolder {  
        TextView title, sub; ImageView icon;  
        VH(View v) {  
            super(v);  
            title = v.findViewById(R.id.title);  
            sub = v.findViewById(R.id.sub);  
            icon = v.findViewById(R.id.icon);  
        }  
    }  
}

}
