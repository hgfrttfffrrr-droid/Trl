package com.gaprom.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class PhotoEditorActivity extends AppCompatActivity {

private Bitmap original;  
private Bitmap current;  
private ImageView preview;  
private SeekBar smoothSeek, brightSeek, contrastSeek;  
private EditText textInput;  
private Spinner patternSpinner;  
private float textSize = 34f;  
private int textColor = Color.WHITE;  
private String pattern = "off";  

@Override protected void onCreate(Bundle b) {  
    super.onCreate(b);  
    setContentView(R.layout.activity_photo_editor);  

    String src = getIntent().getStringExtra("src");  
    original = BitmapFactory.decodeFile(src);  
    if (original == null) { finish(); return; }  
    current = original.copy(Bitmap.Config.ARGB_8888, true);  

    preview = findViewById(R.id.preview);  
    smoothSeek = findViewById(R.id.smooth);  
    brightSeek = findViewById(R.id.bright);  
    contrastSeek = findViewById(R.id.contrast);  
    textInput = findViewById(R.id.textInput);  
    patternSpinner = findViewById(R.id.patternSpinner);  

    patternSpinner.setAdapter(new ArrayAdapter<>(this,  
            android.R.layout.simple_spinner_dropdown_item,  
            new String[]{"بدون الگو", "دایره‌ای", "خطی"}));  
    patternSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {  
        @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {  
            pattern = pos == 0 ? "off" : pos == 1 ? "circle" : "linear";  
            applyFilters();  
        }  
        @Override public void onNothingSelected(AdapterView<?> p) {}  
    });  

    SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {  
        @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { applyFilters(); }  
        @Override public void onStartTrackingTouch(SeekBar s) {}  
        @Override public void onStopTrackingTouch(SeekBar s) {}  
    };  
    smoothSeek.setOnSeekBarChangeListener(l);  
    brightSeek.setOnSeekBarChangeListener(l);  
    contrastSeek.setOnSeekBarChangeListener(l);  

    findViewById(R.id.btnText).setOnClickListener(v -> {  
        String txt = textInput.getText().toString();  
        if (!txt.isEmpty()) { drawTextOnCurrent(); textInput.setText(""); }  
    });  

    findViewById(R.id.btnCancel).setOnClickListener(v -> finish());  
    findViewById(R.id.btnSave).setOnClickListener(v -> save());  

    applyFilters();  
}  

private void applyFilters() {  
    int smooth = smoothSeek.getProgress();  
    int bright = brightSeek.getProgress() - 50;  
    int contrast = contrastSeek.getProgress() - 50;  

    Bitmap bm = original.copy(Bitmap.Config.ARGB_8888, true);  
    Canvas cv = new Canvas(bm);  

    if (smooth > 0) {  
        Bitmap blurred = blur(bm, smooth / 20f + 0.2f);  
        if (blurred != null) bm = blurred;  
        cv = new Canvas(bm);  
    }  

    ColorMatrix cm = new ColorMatrix();  
    float br = 1f + bright * 0.008f;  
    float ct = 1f + contrast * 0.008f;  
    float shift = -128f * (ct - 1f);  
    cm.set(new float[]{  
            ct, 0, 0, 0, shift,  
            0, ct, 0, 0, shift,  
            0, 0, ct, 0, shift,  
            0, 0, 0, 1, 0  
    });  
    Paint p = new Paint();  
    p.setColorFilter(new ColorMatrixColorFilter(cm));  
    cv.drawBitmap(bm, 0, 0, p);  

    if (!"off".equals(pattern)) {  
        Bitmap blurred = blur(bm, 12f);  
        if (blurred != null) {  
            Bitmap masked = Bitmap.createBitmap(bm.getWidth(), bm.getHeight(), Bitmap.Config.ARGB_8888);  
            Canvas mc = new Canvas(masked);  
            mc.drawBitmap(blurred, 0, 0, null);  
            Paint erase = new Paint();  
            erase.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));  
            if ("circle".equals(pattern)) {  
                float cx = bm.getWidth() / 2f, cy = bm.getHeight() * 0.45f;  
                float r = Math.min(bm.getWidth(), bm.getHeight()) * 0.36f;  
                android.graphics.RadialGradient rg = new android.graphics.RadialGradient(  
                        cx, cy, r, new int[]{0xFFFFFFFF, 0x00FFFFFF}, new float[]{0f, 1f},  
                        android.graphics.Shader.TileMode.CLAMP);  
                erase.setShader(rg);  
            } else {  
                android.graphics.LinearGradient lg = new android.graphics.LinearGradient(  
                        0, bm.getHeight() * 0.34f, 0, bm.getHeight() * 0.62f,  
                        new int[]{0x00FFFFFF, 0xFFFFFFFF, 0x00FFFFFF},  
                        new float[]{0f, 0.5f, 1f}, android.graphics.Shader.TileMode.CLAMP);  
                erase.setShader(lg);  
            }  
            mc.drawRect(0, 0, bm.getWidth(), bm.getHeight(), erase);  
            cv.drawBitmap(masked, 0, 0, null);  
        }  
    }  

    current = bm;  
    preview.setImageBitmap(bm);  
}  

private Bitmap blur(Bitmap src, float radius) {  
    try {  
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);  
        Canvas c = new Canvas(out);  
        android.renderscript.RenderScript rs = android.renderscript.RenderScript.create(this);  
        android.renderscript.Allocation in = android.renderscript.Allocation.createFromBitmap(rs, src);  
        android.renderscript.Allocation o = android.renderscript.Allocation.createFromBitmap(rs, out);  
        android.renderscript.ScriptIntrinsicBlur s = android.renderscript.ScriptIntrinsicBlur.create(rs, android.renderscript.Element.U8_4(rs));  
        s.setRadius(Math.max(0.1f, Math.min(25f, radius)));  
        s.setInput(in);  
        s.forEach(o);  
        o.copyTo(out);  
        rs.destroy();  
        return out;  
    } catch (Exception e) { return null; }  
}  

private void drawTextOnCurrent() {  
    String txt = textInput.getText().toString();  
    Bitmap bm = current.copy(Bitmap.Config.ARGB_8888, true);  
    Canvas cv = new Canvas(bm);  
    Paint p = new Paint();  
    p.setColor(textColor);  
    p.setTextSize(textSize * 3);  
    p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));  
    p.setTextAlign(Paint.Align.CENTER);  
    p.setAntiAlias(true);  
    cv.drawText(txt, bm.getWidth() / 2f, bm.getHeight() / 2f, p);  
    current = bm;  
    preview.setImageBitmap(bm);  
}  

private void save() {  
    try {  
        File out = new File(getFilesDir(), "avatar_" + System.currentTimeMillis() + ".jpg");  
        FileOutputStream fos = new FileOutputStream(out);  
        current.compress(Bitmap.CompressFormat.JPEG, 88, fos);  
        fos.close();  
        Intent i = new Intent();  
        i.putExtra("result", out.getAbsolutePath());  
        setResult(RESULT_OK, i);  
        finish();  
    } catch (Exception e) {  
        Toast.makeText(this, "خطا در ذخیره: " + e.getMessage(), Toast.LENGTH_LONG).show();  
    }  
}

}
