package com.gaprom.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

private StringBuilder phone = new StringBuilder();  
private TextView display, error;  
private Button next;  

@Override  
protected void onCreate(Bundle b) {  
    super.onCreate(b);  
    setContentView(R.layout.activity_login);  

    display = findViewById(R.id.display);  
    error = findViewById(R.id.error);  
    next = findViewById(R.id.next);  

    int[] ids = {R.id.k1,R.id.k2,R.id.k3,R.id.k4,R.id.k5,R.id.k6,R.id.k7,R.id.k8,R.id.k9,R.id.k0};  
    String[] digits = {"1","2","3","4","5","6","7","8","9","0"};  
    for (int i = 0; i < ids.length; i++) {  
        final String d = digits[i];  
        findViewById(ids[i]).setOnClickListener(v -> add(d));  
    }  
    findViewById(R.id.kDel).setOnClickListener(v -> del());  
    next.setOnClickListener(v -> go());  

    update();  
}  

private void add(String d) {  
    if (phone.length() >= 10) return;  
    phone.append(d); update();  
}  
private void del() {  
    if (phone.length() > 0) { phone.deleteCharAt(phone.length()-1); update(); }  
}  
private void update() {  
    StringBuilder f = new StringBuilder();  
    for (int i = 0; i < phone.length(); i++) {  
        if (i == 3 || i == 6) f.append(' ');  
        f.append(Utils.faDigits(phone.charAt(i)));  
    }  
    display.setText(f.length() == 0 ? "--- --- ----" : f.toString());  
    next.setEnabled(phone.length() == 10);  
    next.setAlpha(phone.length() == 10 ? 1f : 0.5f);  
}  

private void go() {  
    if (phone.length() != 10) return;  
    String p = phone.toString();  
    DataStore store = DataStore.get(this);  
    if (!Utils.isAdminPhone(p) && store.otpCountLast48h(p) >= Config.OTP_LIMIT) {  
        error.setText("محدودیت درخواست: حداکثر ۲ بار در ۴۸ ساعت");  
        error.setVisibility(View.VISIBLE);  
        return;  
    }  
    error.setVisibility(View.GONE);  
    store.recordOtpRequest(p, System.currentTimeMillis());  

    SmsSender.sendOtp(p, (ok, code, err) -> {  
        if (ok) {  
            Intent i = new Intent(this, VerifyActivity.class);  
            i.putExtra("phone", p);  
            i.putExtra("expected", code);  
            startActivity(i);  
        } else {  
            Toast.makeText(this, "خطا در ارسال پیامک: " + err, Toast.LENGTH_LONG).show();  
        }  
    });  
}

}
