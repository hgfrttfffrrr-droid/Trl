package com.gaprom.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Models {
public static class Profile {
public String phone;
public String first = "";
public String last = "";
public String avatarPath = "";
public long updated = 0;
}

public static class Post {  
    public String text;  
    public long ts;  
    public Map<String, Integer> views = new HashMap<>();  
}  

public static class Channel {  
    public long created;  
    public List<Post> posts = new ArrayList<>();  
}  

public static class Root {  
    public List<String> verified = new ArrayList<>();  
    public Map<String, List<Long>> otpRequests = new HashMap<>();  
    public Map<String, Profile> profiles = new HashMap<>();  
    public Channel channel = new Channel();  
    public Map<String, Long> channelRead = new HashMap<>();  
    public String theme = "dark";  
}

}
