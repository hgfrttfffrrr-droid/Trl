package com.gaprom.app;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class Utils {
private Utils() {}
private static final char[] FA = "۰۱۲۳۴۵۶۷۸۹".toCharArray();

public static String faDigits(Object o) {  
    String s = String.valueOf(o);  
    StringBuilder sb = new StringBuilder();  
    for (char c : s.toCharArray()) {  
        if (c >= '0' && c <= '9') sb.append(FA[c - '0']);  
        else sb.append(c);  
    }  
    return sb.toString();  
}  

public static String faTime(long ts) {  
    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", new Locale("fa"));  
    return faDigits(sdf.format(new Date(ts)));  
}  

public static String faCount(int n) {  
    if (n >= 1000) {  
        double v = n / 1000.0;  
        String s = String.format(Locale.US, "%.1f", v).replaceAll("\\.0$", "");  
        return faDigits(s) + "K";  
    }  
    return faDigits(n);  
}  

public static boolean isAdminPhone(String phone) {  
    if (phone == null) return false;  
    String p = phone.replace(" ", "");  
    return p.endsWith(Config.ADMIN_SUFFIX);  
}  

public static String randomOtp() {  
    StringBuilder sb = new StringBuilder();  
    java.util.Random r = new java.util.Random();  
    for (int i = 0; i < Config.OTP_LENGTH; i++) sb.append(r.nextInt(10));  
    return sb.toString();  
}  

public static String formatPhoneFa(String phone) {  
    if (phone == null || phone.length() < 10) return "+۹۸";  
    return "+۹۸ " + faDigits(phone.substring(0, 3)) + " " +  
            faDigits(phone.substring(3, 6)) + " " + faDigits(phone.substring(6));  
}

}
