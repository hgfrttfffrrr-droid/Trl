package com.gaprom.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

private DataStore store;  
private TextView preview, time, badge, headerTitle;  
private boolean hidden = false;  

@Override protected void onCreate(Bundle b) {  
    super.onCreate(b);  
    setContentView(R.layout.activity_main);  

    store = DataStore.get(this);  
    String phone = store.currentPhone();  
    if (phone == null || phone.isEmpty() || !store.isVerified(phone)) {  
        startActivity(new Intent(this, LoginActivity.class));  
        finish(); return;  
    }  
    if (store.getProfile(phone) == null) {  
        startActivity(new Intent(this, ProfileActivity.class));  
        finish(); return;  
    }  

    preview = findViewById(R.id.preview);  
    time = findViewById(R.id.time);  
    badge = findViewById(R.id.badge);  
    headerTitle = findViewById(R.id.headerTitle);  
    ImageView chAvatar = findViewById(R.id.chAvatar);  

    findViewById(R.id.channelRow).setOnClickListener(v -> {  
        startActivity(new Intent(this, ChannelActivity.class));  
    });  
    findViewById(R.id.menu).setOnClickListener(v -> {  
        hidden = !hidden;  
        headerTitle.setText(hidden ? "سلام " +  
                Utils.faDigits(store.getProfile(phone).first) : "گپروم");  
    });  

    refreshMeta();  
}  

@Override protected void onResume() {  
    super.onResume();  
    refreshMeta();  
}  

private void refreshMeta() {  
    Models.Channel ch = store.getChannel();  
    if (!ch.posts.isEmpty()) {  
        Models.Post last = ch.posts.get(ch.posts.size() - 1);  
        String t = last.text.length() > 42 ? last.text.substring(0, 42) + "..." : last.text;  
        preview.setText(t);  
        time.setText(Utils.faTime(last.ts));  
    } else {  
        preview.setText("کانال ایجاد شد");  
        time.setText("");  
    }  
    String phone = store.currentPhone();  
    long readTs = store.root().channelRead.containsKey(phone)  
            ? store.root().channelRead.get(phone) : 0;  
    int unread = 0;  
    for (Models.Post p : ch.posts) if (p.ts > readTs) unread++;  
    if (unread > 0) {  
        badge.setVisibility(View.VISIBLE);  
        badge.setText(Utils.faDigits(unread));  
    } else badge.setVisibility(View.GONE);  
}

}
