package com.gaprom.app;

public final class Config {
private Config() {}

// ⚠️ همان API_KEY و endpoint سورس Flask شما  
public static final String API_KEY = "10254d7b-8ae8-4dc8-bd5b-86d2267fc483";  
public static final String OTP_ENDPOINT = "https://console.melipayamak.com/api/send/otp/0b25331f57d245c48369e7ed17771951";  

// ⚠️ همان ADMIN_SUFFIX سورس Flask شما  
public static final String ADMIN_SUFFIX = "9939653652";  

// محدودیت ۲ پیامک در ۴۸ ساعت  
public static final int OTP_LIMIT = 2;  
public static final long OTP_WINDOW_MS = 48L * 60 * 60 * 1000;  

public static final int OTP_LENGTH = 6;

}
