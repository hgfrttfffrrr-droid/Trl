package com.gaprom.app;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SmsSender {
public interface Callback2 {
void onResult(boolean ok, String code, String error);
}

private static final OkHttpClient client = new OkHttpClient.Builder()  
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)  
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)  
        .build();  
private static final Handler main = new Handler(Looper.getMainLooper());  

public static void sendOtp(String phone10, Callback2 cb) {  
    String full;  
    if (phone10.startsWith("0")) full = "+98" + phone10.substring(1);  
    else if (!phone10.startsWith("+")) full = "+98" + phone10;  
    else full = phone10;  

    try {  
        JSONObject body = new JSONObject();  
        body.put("to", full);  
        RequestBody rb = RequestBody.create(body.toString(),  
                MediaType.parse("application/json; charset=utf-8"));  
        Request req = new Request.Builder()  
                .url(Config.OTP_ENDPOINT)  
                .addHeader("Content-Type", "application/json")  
                .addHeader("x-api-key", Config.API_KEY)  
                .post(rb)  
                .build();  

        client.newCall(req).enqueue(new Callback() {  
            @Override public void onFailure(Call call, IOException e) {  
                main.post(() -> cb.onResult(false, null, e.getMessage()));  
            }  
            @Override public void onResponse(Call call, Response response) {  
                try {  
                    String s = response.body() != null ? response.body().string() : "";  
                    if (response.isSuccessful()) {  
                        JSONObject o = new JSONObject(s);  
                        String code = o.optString("code", null);  
                        if (code != null && !code.isEmpty()) {  
                            main.post(() -> cb.onResult(true, code, null));  
                            return;  
                        }  
                    }  
                    main.post(() -> cb.onResult(false, null, "HTTP " + response.code()));  
                } catch (Exception e) {  
                    main.post(() -> cb.onResult(false, null, e.getMessage()));  
                }  
            }  
        });  
    } catch (Exception e) {  
        cb.onResult(false, null, e.getMessage());  
    }  
}

}
