package com.gaprom.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class ProfileActivity extends AppCompatActivity {

private DataStore store;  
private String phone;  
private ImageView avatar;  
private EditText firstName, lastName;  
private ActivityResultLauncher<Intent> picker;  

@Override  
protected void onCreate(Bundle b) {  
    super.onCreate(b);  
    setContentView(R.layout.activity_profile);  

    store = DataStore.get(this);  
    phone = store.currentPhone();  
    if (phone == null || phone.isEmpty()) { finish(); return; }  

    avatar = findViewById(R.id.avatar);  
    firstName = findViewById(R.id.firstName);  
    lastName = findViewById(R.id.lastName);  

    Models.Profile p = store.getProfile(phone);  
    if (p != null) {  
        firstName.setText(p.first);  
        lastName.setText(p.last);  
        if (!TextUtils.isEmpty(p.avatarPath)) loadAvatar(p.avatarPath);  
    }  

    picker = registerForActivityResult(  
            new ActivityResultContracts.StartActivityForResult(), r -> {  
                if (r.getResultCode() == RESULT_OK && r.getData() != null && r.getData().getData() != null) {  
                    Uri uri = r.getData().getData();  
                    openEditor(uri);  
                }  
            });  

    avatar.setOnClickListener(v -> picker.launch(  
            new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)));  

    findViewById(R.id.btnSave).setOnClickListener(v -> save());  
}  

private void loadAvatar(String path) {  
    File f = new File(path);  
    if (f.exists()) {  
        Bitmap bm = BitmapFactory.decodeFile(path);  
        if (bm != null) avatar.setImageBitmap(bm);  
    }  
}  

private void openEditor(Uri uri) {  
    try {  
        InputStream in = getContentResolver().openInputStream(uri);  
        File tmp = new File(getCacheDir(), "picked_" + System.currentTimeMillis() + ".jpg");  
        try (FileOutputStream out = new FileOutputStream(tmp)) {  
            byte[] buf = new byte[8192]; int n;  
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);  
        }  
        in.close();  
        Intent i = new Intent(this, PhotoEditorActivity.class);  
        i.putExtra("src", tmp.getAbsolutePath());  
        startActivityForResult(i, 1001);  
    } catch (Exception e) {  
        Toast.makeText(this, "خطا: " + e.getMessage(), Toast.LENGTH_SHORT).show();  
    }  
}  

@Override protected void onActivityResult(int req, int res, Intent data) {  
    super.onActivityResult(req, res, data);  
    if (req == 1001 && res == RESULT_OK && data != null) {  
        String path = data.getStringExtra("result");  
        if (path != null) {  
            store.setAvatar(phone, path);  
            loadAvatar(path);  
        }  
    }  
}  

private void save() {  
    String f = firstName.getText().toString().trim();  
    if (f.isEmpty()) { firstName.setError("نام الزامی است"); return; }  
    store.saveProfile(phone, f, lastName.getText().toString().trim());  
    startActivity(new Intent(this, MainActivity.class));  
    finish();  
}

}
