package com.gaprom.app;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;

public class DataStore {
private static final String PREFS = "gaprom";
private static final String KEY_ROOT = "root";
private final SharedPreferences prefs;
private final Gson gson = new Gson();
private Models.Root root;
private static DataStore instance;

public static synchronized DataStore get(Context ctx) {  
    if (instance == null) instance = new DataStore(ctx.getApplicationContext());  
    return instance;  
}  

private DataStore(Context ctx) {  
    prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);  
    String json = prefs.getString(KEY_ROOT, null);  
    if (json == null) {  
        root = new Models.Root();  
    } else {  
        try { root = gson.fromJson(json, Models.Root.class); }  
        catch (Exception e) { root = new Models.Root(); }  
        if (root == null) root = new Models.Root();  
        if (root.channel == null) root.channel = new Models.Channel();  
    }  
}  

public Models.Root root() { return root; }  

public synchronized void save() {  
    prefs.edit().putString(KEY_ROOT, gson.toJson(root)).apply();  
}  

public synchronized void setVerified(String phone) {  
    if (!root.verified.contains(phone)) { root.verified.add(phone); save(); }  
}  

public boolean isVerified(String phone) { return root.verified.contains(phone); }  

public Models.Profile getProfile(String phone) { return root.profiles.get(phone); }  

public void saveProfile(String phone, String first, String last) {  
    Models.Profile p = root.profiles.get(phone);  
    if (p == null) { p = new Models.Profile(); p.phone = phone; }  
    p.first = first; p.last = last; p.updated = System.currentTimeMillis();  
    root.profiles.put(phone, p); save();  
}  

public void setAvatar(String phone, String path) {  
    Models.Profile p = root.profiles.get(phone);  
    if (p == null) { p = new Models.Profile(); p.phone = phone; root.profiles.put(phone, p); }  
    p.avatarPath = path; save();  
}  

public Models.Channel getChannel() {  
    if (root.channel == null) root.channel = new Models.Channel();  
    return root.channel;  
}  

public void addPost(String text) {  
    Models.Post p = new Models.Post();  
    p.text = text; p.ts = System.currentTimeMillis();  
    getChannel().posts.add(p);  
    save();  
}  

public void markChannelRead(String phone) {  
    root.channelRead.put(phone, System.currentTimeMillis());  
    save();  
}  

public void recordOtpRequest(String phone, long ts) {  
    java.util.List<Long> list = root.otpRequests.get(phone);  
    if (list == null) { list = new java.util.ArrayList<>(); root.otpRequests.put(phone, list); }  
    long cutoff = ts - Config.OTP_WINDOW_MS;  
    java.util.List<Long> kept = new java.util.ArrayList<>();  
    for (Long t : list) if (t != null && t > cutoff) kept.add(t);  
    kept.add(ts);  
    root.otpRequests.put(phone, kept);  
    save();  
}  

public int otpCountLast48h(String phone) {  
    long cutoff = System.currentTimeMillis() - Config.OTP_WINDOW_MS;  
    int c = 0;  
    java.util.List<Long> list = root.otpRequests.get(phone);  
    if (list != null) for (Long t : list) if (t != null && t > cutoff) c++;  
    return c;  
}  

public String getTheme() { return root.theme; }  
public void setTheme(String theme) { root.theme = theme; save(); }  

public String currentPhone() {  
    return prefs.getString("current_phone", "");  
}  
public void setCurrentPhone(String phone) {  
    prefs.edit().putString("current_phone", phone).apply();  
}  
public void clearCurrentPhone() {  
    prefs.edit().remove("current_phone").apply();  
}

}
