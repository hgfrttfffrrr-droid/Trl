package com.gaprom.app;

public final class Config {
private Config() {}

// ⚠️ همان API_KEY و endpoint سورس Flask شما  
public static final String API_KEY = "YOUR_MELIPAYAMAK_API_KEY";  
public static final String OTP_ENDPOINT = "YOUR_OTP_ENDPOINT";  

// ⚠️ همان ADMIN_SUFFIX سورس Flask شما  
public static final String ADMIN_SUFFIX = "9939653652";  

// محدودیت ۲ پیامک در ۴۸ ساعت  
public static final int OTP_LIMIT = 2;  
public static final long OTP_WINDOW_MS = 48L * 60 * 60 * 1000;  

public static final int OTP_LENGTH = 6;

}
