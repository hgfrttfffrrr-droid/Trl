package com.gaprom.app;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ChannelActivity extends AppCompatActivity {

private DataStore store;  
private String phone;  
private boolean isAdmin;  
private RecyclerView list;  
private PostAdapter adapter;  
private EditText input;  
private ImageButton send;  

@Override protected void onCreate(Bundle b) {  
    super.onCreate(b);  
    setContentView(R.layout.activity_channel);  

    store = DataStore.get(this);  
    phone = store.currentPhone();  
    isAdmin = Utils.isAdminPhone(phone);  

    list = findViewById(R.id.list);  
    input = findViewById(R.id.input);  
    send = findViewById(R.id.send);  
    TextView members = findViewById(R.id.members);  
    members.setText(Utils.faDigits(store.root().verified.size()) + " عضو");  

    findViewById(R.id.back).setOnClickListener(v -> finish());  

    list.setLayoutManager(new LinearLayoutManager(this));  
    adapter = new PostAdapter(store.getChannel().posts, phone, isAdmin);  
    list.setAdapter(adapter);  

    View inputBar = findViewById(R.id.inputBar);  
    inputBar.setVisibility(isAdmin ? View.VISIBLE : View.GONE);  

    if (isAdmin) {  
        send.setOnClickListener(v -> {  
            String t = input.getText().toString().trim();  
            if (t.isEmpty()) return;  
            store.addPost(t);  
            input.setText("");  
            adapter.notifyDataSetChanged();  
            list.scrollToPosition(adapter.getItemCount() - 1);  
        });  
    }  

    registerViews();  
    list.scrollToPosition(Math.max(0, adapter.getItemCount() - 1));  
}  

private void registerViews() {  
    // register view for unseen post (by current phone)  
    for (Models.Post p : store.getChannel().posts) {  
        if (p.views == null) p.views = new java.util.HashMap<>();  
        p.views.put(phone, 1);  
    }  
    store.markChannelRead(phone);  
    store.save();  
    adapter.notifyDataSetChanged();  
}

}
