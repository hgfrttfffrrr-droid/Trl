package com.gaprom.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class VerifyActivity extends AppCompatActivity {

private String phone, expected;  
private StringBuilder code = new StringBuilder();  
private TextView display, timerText, resend;  
private CountDownTimer timer;  

@Override  
protected void onCreate(Bundle b) {  
    super.onCreate(b);  
    setContentView(R.layout.activity_verify);  

    phone = getIntent().getStringExtra("phone");  
    expected = getIntent().getStringExtra("expected");  

    display = findViewById(R.id.display);  
    timerText = findViewById(R.id.timerText);  
    resend = findViewById(R.id.resend);  
    ((TextView) findViewById(R.id.phoneLbl)).setText(Utils.formatPhoneFa(phone));  

    int[] ids = {R.id.k1,R.id.k2,R.id.k3,R.id.k4,R.id.k5,R.id.k6,R.id.k7,R.id.k8,R.id.k9,R.id.k0};  
    String[] digits = {"1","2","3","4","5","6","7","8","9","0"};  
    for (int i = 0; i < ids.length; i++) {  
        final String d = digits[i];  
        findViewById(ids[i]).setOnClickListener(v -> add(d));  
    }  
    findViewById(R.id.kDel).setOnClickListener(v -> del());  

    resend.setOnClickListener(v -> resendCode());  
    startTimer();  
    update();  
}  

private void add(String d) {  
    if (code.length() >= Config.OTP_LENGTH) return;  
    code.append(d); update();  
    if (code.length() == Config.OTP_LENGTH) check();  
}  
private void del() {  
    if (code.length() > 0) { code.deleteCharAt(code.length()-1); update(); }  
}  
private void update() {  
    StringBuilder s = new StringBuilder();  
    for (int i = 0; i < Config.OTP_LENGTH; i++) {  
        if (i > 0) s.append("  ");  
        s.append(i < code.length() ? Utils.faDigits(code.charAt(i)) : "—");  
    }  
    display.setText(s.toString());  
}  
private void check() {  
    if (code.toString().equals(expected)) {  
        DataStore store = DataStore.get(this);  
        store.setVerified(phone);  
        store.setCurrentPhone(phone);  
        if (store.getProfile(phone) == null) startActivity(new Intent(this, ProfileActivity.class));  
        else startActivity(new Intent(this, MainActivity.class));  
        finish();  
    } else {  
        Toast.makeText(this, "کد اشتباه است", Toast.LENGTH_SHORT).show();  
        code.setLength(0); update();  
    }  
}  

private void startTimer() {  
    resend.setVisibility(View.GONE);  
    timerText.setVisibility(View.VISIBLE);  
    if (timer != null) timer.cancel();  
    timer = new CountDownTimer(120_000, 1000) {  
        @Override public void onTick(long ms) {  
            int s = (int) (ms / 1000);  
            timerText.setText("شما می‌توانید پیامک جدیدی را در " +  
                    Utils.faDigits(s / 60) + ":" + Utils.faDigits(String.format("%02d", s % 60)) +  
                    " درخواست کنید");  
        }  
        @Override public void onFinish() {  
            timerText.setVisibility(View.GONE);  
            resend.setVisibility(View.VISIBLE);  
        }  
    }.start();  
}  

private void resendCode() {  
    DataStore store = DataStore.get(this);  
    if (!Utils.isAdminPhone(phone) && store.otpCountLast48h(phone) >= Config.OTP_LIMIT) {  
        Toast.makeText(this, "محدودیت ۴۸ ساعته فعال است", Toast.LENGTH_LONG).show();  
        return;  
    }  
    store.recordOtpRequest(phone, System.currentTimeMillis());  
    SmsSender.sendOtp(phone, (ok, c, e) -> {  
        if (ok) { expected = c; code.setLength(0); update(); startTimer(); }  
        else Toast.makeText(this, "خطا در ارسال: " + e, Toast.LENGTH_LONG).show();  
    });  
}  

@Override protected void onDestroy() {  
    super.onDestroy();  
    if (timer != null) timer.cancel();  
}

}
