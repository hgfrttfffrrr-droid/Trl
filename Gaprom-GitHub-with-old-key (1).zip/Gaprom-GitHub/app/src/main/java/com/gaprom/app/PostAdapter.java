package com.gaprom.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.VH> {
private final List<Models.Post> posts;
private final String phone;
private final boolean own;

public PostAdapter(List<Models.Post> posts, String phone, boolean own) {  
    this.posts = posts; this.phone = phone; this.own = own;  
}  

@NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int vt) {  
    View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_post, p, false);  
    return new VH(v);  
}  
@Override public void onBindViewHolder(@NonNull VH h, int pos) {  
    Models.Post p = posts.get(pos);  
    h.text.setText(p.text);  
    int views = p.views == null ? 0 : p.views.size();  
    h.meta.setText(Utils.faCount(views) + "  ·  " + Utils.faTime(p.ts));  
    if (own) {  
        h.text.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);  
    }  
}  
@Override public int getItemCount() { return posts.size(); }  
static class VH extends RecyclerView.ViewHolder {  
    TextView text, meta;  
    VH(View v) { super(v); text = v.findViewById(R.id.text); meta = v.findViewById(R.id.meta); }  
}

}
